# BoSLcam rev1.3.0

Revision date: 2026-10-14. Production validation is not complete.

Open [owts/owts.kicad_pro](owts/owts.kicad_pro) in KiCad 9.
The schematic, PCB and project symbol/footprint libraries are included.
Manufacturing exports and build notes are in [owts/production/](owts/production/).

Review the [PCB DRC](validation/BoSLcam_drc_rev1.3.0.json) and
[schematic ERC](validation/BoSLcam_erc_rev1.3.0.json) reports before manufacture.
DRC: 7 solder-mask bridge errors at U5, 61 warnings, zero unconnected pads,
zero schematic/PCB parity issues. ERC: 18 errors and 415 warnings.
U5 solder-mask openings and fabrication capability for 0.30/0.20 mm vias
require review. Firmware and assembled-board validation remain outstanding.

U1 and U7 are DNP in the schematic and PCB and omitted from placement exports.
C1 is 100 uF in the BOM, matching its specified PCG1A101MCL1GS part.
R1/R3/R9 remain 47 ohm in the BOM and 49 ohm in the schematic/placement metadata.

The separate rev1.3.0 BOM, schematic PDF and layout PDF accompany this archive
in the repository's EDA directory.
