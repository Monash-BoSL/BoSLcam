BoSLcam rev1.3.0 manufacturing exports
Revision date: 2026-10-14

Status: engineering review; production validation remains outstanding.
KiCad DRC: 7 solder-mask bridge errors at U5, 61 warnings,
0 unconnected pads and 0 schematic/PCB parity issues.
The U5 mask openings require fabrication/assembly review. The board also uses
0.30 mm copper / 0.20 mm drill vias; confirm the fabricator's process capability.

Gerbers: four copper layers, front/rear mask, paste and silkscreen, board outline.
Drills: Excellon, inch units, absolute origin, separate plated/non-plated files.
Placement: millimetres, absolute origin, separate front/rear files, SMD parts only.
U1 and U7 are DNP and excluded from placement files, matching the schematic,
PCB and BOM. C1 is 100 uF, matching the specified PCG1A101MCL1GS.
R1/R3/R9 remain 47 ohm in the BOM and 49 ohm in the schematic/placement values.

The corresponding BOM and schematic/layout PDFs accompany these exports in
EDA/. The source archive includes the current DRC/ERC reports.
Sensor firmware and assembled-board validation are still outstanding.
